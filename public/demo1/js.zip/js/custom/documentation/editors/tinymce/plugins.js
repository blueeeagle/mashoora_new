/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./resources/assets/core/js/custom/documentation/editors/tinymce/plugins.js":
/*!**********************************************************************************!*\
  !*** ./resources/assets/core/js/custom/documentation/editors/tinymce/plugins.js ***!
  \**********************************************************************************/
/***/ (() => {

eval(" // Class definition\n\nvar KTFormsTinyMCEPlugins = function () {\n  // Private functions\n  var examplePlugins = function examplePlugins() {\n    tinymce.init({\n      selector: '#kt_docs_tinymce_plugins',\n      toolbar: 'advlist | autolink | link image | lists charmap | print preview',\n      plugins: 'advlist autolink link image lists charmap print preview'\n    });\n  };\n\n  return {\n    // Public Functions\n    init: function init() {\n      examplePlugins();\n    }\n  };\n}(); // On document ready\n\n\nKTUtil.onDOMContentLoaded(function () {\n  KTFormsTinyMCEPlugins.init();\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9yZXNvdXJjZXMvYXNzZXRzL2NvcmUvanMvY3VzdG9tL2RvY3VtZW50YXRpb24vZWRpdG9ycy90aW55bWNlL3BsdWdpbnMuanMuanMiLCJtYXBwaW5ncyI6IkNBRUE7O0FBQ0EsSUFBSUEscUJBQXFCLEdBQUcsWUFBVztFQUNuQztFQUNBLElBQUlDLGNBQWMsR0FBRyxTQUFqQkEsY0FBaUIsR0FBVztJQUM1QkMsT0FBTyxDQUFDQyxJQUFSLENBQWE7TUFDVEMsUUFBUSxFQUFFLDBCQUREO01BRVRDLE9BQU8sRUFBRSxpRUFGQTtNQUdUQyxPQUFPLEVBQUc7SUFIRCxDQUFiO0VBS0gsQ0FORDs7RUFRQSxPQUFPO0lBQ0g7SUFDQUgsSUFBSSxFQUFFLGdCQUFXO01BQ2JGLGNBQWM7SUFDakI7RUFKRSxDQUFQO0FBTUgsQ0FoQjJCLEVBQTVCLEMsQ0FrQkE7OztBQUNBTSxNQUFNLENBQUNDLGtCQUFQLENBQTBCLFlBQVc7RUFDakNSLHFCQUFxQixDQUFDRyxJQUF0QjtBQUNILENBRkQiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9yZXNvdXJjZXMvYXNzZXRzL2NvcmUvanMvY3VzdG9tL2RvY3VtZW50YXRpb24vZWRpdG9ycy90aW55bWNlL3BsdWdpbnMuanM/OWRjOCJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzdHJpY3RcIjtcclxuXHJcbi8vIENsYXNzIGRlZmluaXRpb25cclxudmFyIEtURm9ybXNUaW55TUNFUGx1Z2lucyA9IGZ1bmN0aW9uKCkge1xyXG4gICAgLy8gUHJpdmF0ZSBmdW5jdGlvbnNcclxuICAgIHZhciBleGFtcGxlUGx1Z2lucyA9IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIHRpbnltY2UuaW5pdCh7XHJcbiAgICAgICAgICAgIHNlbGVjdG9yOiAnI2t0X2RvY3NfdGlueW1jZV9wbHVnaW5zJyxcclxuICAgICAgICAgICAgdG9vbGJhcjogJ2Fkdmxpc3QgfCBhdXRvbGluayB8IGxpbmsgaW1hZ2UgfCBsaXN0cyBjaGFybWFwIHwgcHJpbnQgcHJldmlldycsXHJcbiAgICAgICAgICAgIHBsdWdpbnMgOiAnYWR2bGlzdCBhdXRvbGluayBsaW5rIGltYWdlIGxpc3RzIGNoYXJtYXAgcHJpbnQgcHJldmlldydcclxuICAgICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIC8vIFB1YmxpYyBGdW5jdGlvbnNcclxuICAgICAgICBpbml0OiBmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgZXhhbXBsZVBsdWdpbnMoKTtcclxuICAgICAgICB9XHJcbiAgICB9O1xyXG59KCk7XHJcblxyXG4vLyBPbiBkb2N1bWVudCByZWFkeVxyXG5LVFV0aWwub25ET01Db250ZW50TG9hZGVkKGZ1bmN0aW9uKCkge1xyXG4gICAgS1RGb3Jtc1RpbnlNQ0VQbHVnaW5zLmluaXQoKTtcclxufSk7XHJcbiJdLCJuYW1lcyI6WyJLVEZvcm1zVGlueU1DRVBsdWdpbnMiLCJleGFtcGxlUGx1Z2lucyIsInRpbnltY2UiLCJpbml0Iiwic2VsZWN0b3IiLCJ0b29sYmFyIiwicGx1Z2lucyIsIktUVXRpbCIsIm9uRE9NQ29udGVudExvYWRlZCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./resources/assets/core/js/custom/documentation/editors/tinymce/plugins.js\n");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval-source-map devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./resources/assets/core/js/custom/documentation/editors/tinymce/plugins.js"]();
/******/ 	
/******/ })()
;