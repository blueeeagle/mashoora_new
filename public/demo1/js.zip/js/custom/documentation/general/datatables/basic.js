/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./resources/assets/core/js/custom/documentation/general/datatables/basic.js":
/*!***********************************************************************************!*\
  !*** ./resources/assets/core/js/custom/documentation/general/datatables/basic.js ***!
  \***********************************************************************************/
/***/ (() => {

eval(" // Class definition\n\nvar KTDatatablesBasic = function () {\n  // Private functions\n  var _initExample1 = function _initExample1() {\n    $(\"#kt_datatable_example_1\").DataTable();\n  };\n\n  var _initExample2 = function _initExample2() {\n    $(\"#kt_datatable_example_2\").DataTable({\n      \"scrollY\": \"500px\",\n      \"scrollCollapse\": true,\n      \"paging\": false,\n      \"dom\": \"<'table-responsive'tr>\"\n    });\n  };\n\n  var _initExample3 = function _initExample3() {\n    $(\"#kt_datatable_example_3\").DataTable({\n      \"scrollX\": true\n    });\n  };\n\n  var _initExample4 = function _initExample4() {\n    $(\"#kt_datatable_example_4\").DataTable({\n      \"scrollY\": 300,\n      \"scrollX\": true\n    });\n  }; // Public methods\n\n\n  return {\n    init: function init() {\n      _initExample1();\n\n      _initExample2();\n\n      _initExample3();\n\n      _initExample4();\n    }\n  };\n}(); // On document ready\n\n\nKTUtil.onDOMContentLoaded(function () {\n  KTDatatablesBasic.init();\n});//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9yZXNvdXJjZXMvYXNzZXRzL2NvcmUvanMvY3VzdG9tL2RvY3VtZW50YXRpb24vZ2VuZXJhbC9kYXRhdGFibGVzL2Jhc2ljLmpzLmpzIiwibWFwcGluZ3MiOiJDQUVBOztBQUNBLElBQUlBLGlCQUFpQixHQUFHLFlBQVk7RUFDaEM7RUFFQSxJQUFJQyxhQUFhLEdBQUcsU0FBaEJBLGFBQWdCLEdBQVc7SUFDM0JDLENBQUMsQ0FBQyx5QkFBRCxDQUFELENBQTZCQyxTQUE3QjtFQUNILENBRkQ7O0VBSUEsSUFBSUMsYUFBYSxHQUFHLFNBQWhCQSxhQUFnQixHQUFXO0lBQzNCRixDQUFDLENBQUMseUJBQUQsQ0FBRCxDQUE2QkMsU0FBN0IsQ0FBdUM7TUFDbkMsV0FBa0IsT0FEaUI7TUFFbkMsa0JBQWtCLElBRmlCO01BR25DLFVBQWtCLEtBSGlCO01BSW5DLE9BQVM7SUFKMEIsQ0FBdkM7RUFNSCxDQVBEOztFQVNBLElBQUlFLGFBQWEsR0FBRyxTQUFoQkEsYUFBZ0IsR0FBVztJQUMzQkgsQ0FBQyxDQUFDLHlCQUFELENBQUQsQ0FBNkJDLFNBQTdCLENBQXVDO01BQ25DLFdBQVc7SUFEd0IsQ0FBdkM7RUFHSCxDQUpEOztFQU1BLElBQUlHLGFBQWEsR0FBRyxTQUFoQkEsYUFBZ0IsR0FBVztJQUMzQkosQ0FBQyxDQUFDLHlCQUFELENBQUQsQ0FBNkJDLFNBQTdCLENBQXVDO01BQ25DLFdBQVcsR0FEd0I7TUFFbkMsV0FBVztJQUZ3QixDQUF2QztFQUlILENBTEQsQ0F0QmdDLENBNkJoQzs7O0VBQ0EsT0FBTztJQUNISSxJQUFJLEVBQUUsZ0JBQVk7TUFDZE4sYUFBYTs7TUFDYkcsYUFBYTs7TUFDYkMsYUFBYTs7TUFDYkMsYUFBYTtJQUNoQjtFQU5FLENBQVA7QUFRSCxDQXRDdUIsRUFBeEIsQyxDQXdDQTs7O0FBQ0FFLE1BQU0sQ0FBQ0Msa0JBQVAsQ0FBMEIsWUFBVztFQUNqQ1QsaUJBQWlCLENBQUNPLElBQWxCO0FBQ0gsQ0FGRCIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL3Jlc291cmNlcy9hc3NldHMvY29yZS9qcy9jdXN0b20vZG9jdW1lbnRhdGlvbi9nZW5lcmFsL2RhdGF0YWJsZXMvYmFzaWMuanM/YzE5ZSJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzdHJpY3RcIjtcclxuXHJcbi8vIENsYXNzIGRlZmluaXRpb25cclxudmFyIEtURGF0YXRhYmxlc0Jhc2ljID0gZnVuY3Rpb24gKCkge1xyXG4gICAgLy8gUHJpdmF0ZSBmdW5jdGlvbnNcclxuXHJcbiAgICB2YXIgX2luaXRFeGFtcGxlMSA9IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICQoXCIja3RfZGF0YXRhYmxlX2V4YW1wbGVfMVwiKS5EYXRhVGFibGUoKTtcclxuICAgIH1cclxuXHJcbiAgICB2YXIgX2luaXRFeGFtcGxlMiA9IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICQoXCIja3RfZGF0YXRhYmxlX2V4YW1wbGVfMlwiKS5EYXRhVGFibGUoe1xyXG4gICAgICAgICAgICBcInNjcm9sbFlcIjogICAgICAgIFwiNTAwcHhcIixcclxuICAgICAgICAgICAgXCJzY3JvbGxDb2xsYXBzZVwiOiB0cnVlLFxyXG4gICAgICAgICAgICBcInBhZ2luZ1wiOiAgICAgICAgIGZhbHNlLFxyXG4gICAgICAgICAgICBcImRvbVwiOiAgIFwiPCd0YWJsZS1yZXNwb25zaXZlJ3RyPlwiIFxyXG4gICAgICAgIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIHZhciBfaW5pdEV4YW1wbGUzID0gZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgJChcIiNrdF9kYXRhdGFibGVfZXhhbXBsZV8zXCIpLkRhdGFUYWJsZSh7XHJcbiAgICAgICAgICAgIFwic2Nyb2xsWFwiOiB0cnVlXHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG4gICAgdmFyIF9pbml0RXhhbXBsZTQgPSBmdW5jdGlvbigpIHtcclxuICAgICAgICAkKFwiI2t0X2RhdGF0YWJsZV9leGFtcGxlXzRcIikuRGF0YVRhYmxlKHtcclxuICAgICAgICAgICAgXCJzY3JvbGxZXCI6IDMwMCxcclxuICAgICAgICAgICAgXCJzY3JvbGxYXCI6IHRydWVcclxuICAgICAgICB9KTtcclxuICAgIH0gIFxyXG5cclxuICAgIC8vIFB1YmxpYyBtZXRob2RzXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIGluaXQ6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgICAgX2luaXRFeGFtcGxlMSgpO1xyXG4gICAgICAgICAgICBfaW5pdEV4YW1wbGUyKCk7XHJcbiAgICAgICAgICAgIF9pbml0RXhhbXBsZTMoKTtcclxuICAgICAgICAgICAgX2luaXRFeGFtcGxlNCgpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufSgpO1xyXG5cclxuLy8gT24gZG9jdW1lbnQgcmVhZHlcclxuS1RVdGlsLm9uRE9NQ29udGVudExvYWRlZChmdW5jdGlvbigpIHtcclxuICAgIEtURGF0YXRhYmxlc0Jhc2ljLmluaXQoKTtcclxufSk7Il0sIm5hbWVzIjpbIktURGF0YXRhYmxlc0Jhc2ljIiwiX2luaXRFeGFtcGxlMSIsIiQiLCJEYXRhVGFibGUiLCJfaW5pdEV4YW1wbGUyIiwiX2luaXRFeGFtcGxlMyIsIl9pbml0RXhhbXBsZTQiLCJpbml0IiwiS1RVdGlsIiwib25ET01Db250ZW50TG9hZGVkIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./resources/assets/core/js/custom/documentation/general/datatables/basic.js\n");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval-source-map devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./resources/assets/core/js/custom/documentation/general/datatables/basic.js"]();
/******/ 	
/******/ })()
;