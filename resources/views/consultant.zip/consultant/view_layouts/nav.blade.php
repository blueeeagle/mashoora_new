<div class="card-body pt-1 pb-0">
    <ul class="nav nav-stretch nav-line-tabs nav-line-tabs-2x border-transparent fs-5 fw-bolder">
        <li class="nav-item mt-2">
            <a class="nav-link text-active-primary ms-0 me-10 py-5 active" data-bs-toggle="tab" href="#kt_tab_pane_1" >DashBoard</a>
        </li>
        <li class="nav-item mt-2">
            <a class="nav-link text-active-primary ms-0 me-10 py-5" data-bs-toggle="tab" id="test"  href="#kt_tab_pane_2">Transaction</a>
        </li>
        
        <li class="nav-item mt-2">
         <a class="nav-link text-active-primary ms-0 me-10 py-5" data-bs-toggle="tab" href="#kt_tab_pane_3">Appointment</a>
        </li>
        <!--<li class="nav-item mt-2">-->
        <!--    <a class="nav-link text-active-primary ms-0 me-10 py-5" data-bs-toggle="tab" href="#wallet_tab">Wallet & Transaction</a>-->
        <!--</li>-->
        {{-- <li class="nav-item mt-2">
            <a class="nav-link text-active-primary ms-0 me-10 py-5" data-bs-toggle="tab" id="test"  href="#kt_tab_pane_2">Calender</a>
        </li>
        <li class="nav-item mt-2">
            <a class="nav-link text-active-primary ms-0 me-10 py-5" data-bs-toggle="tab" href="#kt_tab_pane_3">Scheduling</a>
        </li>
        <li class="nav-item mt-2">
            <a class="nav-link text-active-primary ms-0 me-10 py-5" data-bs-toggle="tab" href="#kt_tab_pane_4">Appointments History</a>
        </li>
          <li class="nav-item mt-2">
            <a class="nav-link text-active-primary ms-0 me-10 py-5" data-bs-toggle="tab" href="#kt_tab_pane_5">Offer History</a>
        </li>

     
        <li class="nav-item mt-2">
            <a class="nav-link text-active-primary ms-0 me-10 py-5" data-bs-toggle="tab" href="#kt_tab_pane_8">Review & Ratings</a>
        </li> --}}
    </ul>
</div>
