
<div class="d-flex flex-column flex-column-fluid">
    <div id="kt_app_content" class="app-content flex-column-fluid" style="margin-bottom: 21px;">
        <!--begin::Content container-->
        <div id="kt_app_content_container" class="app-container container-xxl">
            <!--begin::Card-->
            <div class="card">
                <!--begin::Card header-->
                <div class="card-header border-0">
                    <!--begin::Card title-->
                    <div class="card-title">
                      
                    </div>
                </div>
                <!--end::Card header-->
                <!--begin::Card body-->
                <div class="card-body pt-0">
                    <!--begin::Table-->
                    <div id="kt_customers_table_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                        <div class="table-responsive" style="margin-top:-25px;">
                            <table class="table table-row-bordered table-row-dashed gy-5" id="kt_customers">
                                <thead>
                                    <tr class="fw-semibold fs-6 text-gray-800">
                                        <th>Booking Info</th>
                                        <th>Consultant Info</th>
                                        <th>Customer Info</th>
                                        <th>Consultant</th>
                                        <th>Customer</th>
                                        <th>Booking Status</th>
                                    </tr>
                                </thead>
                            </table>

                        </div>

                    </div>
                </div>
                <!--end::Card body-->
            </div>
        </div>
        <!--end::Content container-->
    </div>
    <!--end::Content-->
</div>