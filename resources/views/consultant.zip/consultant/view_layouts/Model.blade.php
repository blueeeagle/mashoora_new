@include('consultant.view_layouts.model.personal_details')
@include('consultant.view_layouts.model.Commission')
@include('consultant.view_layouts.model.last_update')
@include('consultant.view_layouts.model.bank_details')
