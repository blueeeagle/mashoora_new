<x-base-layout>
    
    <div class="d-flex flex-column flex-column-fluid">
        <!--begin::Toolbar-->
        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">
            <!--begin::Toolbar container-->
            <div id="kt_app_toolbar_container" class="app-container container-xxl d-flex flex-stack">
                <!--begin::Page title-->
                <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">
                    <!--begin::Title-->
                    <h1 class="page-heading d-flex text-dark fw-bold fs-3 flex-column justify-content-center my-0">Notification Setting</h1>
                    <!--end::Title-->
                    <!--begin::Breadcrumb-->
                    <ul class="breadcrumb breadcrumb-separatorless fw-semibold fs-7 my-0 pt-1">
                        <!--begin::Item-->
                        <li class="breadcrumb-item text-muted">
                            <a href="#" class="text-muted text-hover-primary">Home</a>
                        </li>
                        <!--end::Item-->
                        <!--begin::Item-->
                        <li class="breadcrumb-item">
                            <span class="bullet bg-gray-400 w-5px h-2px"></span>
                        </li>
                        <!--end::Item-->
                        <!--begin::Item-->
                        <li class="breadcrumb-item text-muted">Notification</li>

                        <!--end::Item-->
                    </ul>
                    <!--end::Breadcrumb-->
                </div>
                <!--end::Page title-->
                <!--begin::Actions-->
                
                <!--end::Actions-->
            </div>
            <!--end::Toolbar container-->
        </div>
        <!--end::Toolbar-->
        <!--begin::Content-->


        <div id="kt_app_content" class="app-content flex-column-fluid">
            <!--begin::Content container-->
            <div id="kt_app_content_container" class="app-container container-xxl">
                <!--begin::Card-->
                <div class="card">
                    <!--begin::Card header-->
                    <div class="card-header border-0">
                        <!--begin::Card title-->
                        
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body pt-0">
                        <!--begin::Table-->
                        <div id="kt_customers_table_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                            <div class="table-responsive" style="margin-top:-25px;">
                            <form method="post" action="{{ route('notification.notification.store') }}" id="formCreate">
                                @csrf
                                <table class="table table-row-bordered table-row-dashed gy-5" id="kt_customers_table">
                                <col>
                                <colgroup span="2"></colgroup>
                                <colgroup span="2"></colgroup>
                                <tbody style="border: double;text-align: center;">
                                <tr>
                                    <td rowspan="2">Scenario</td>
                                    <td rowspan="2">Action Taken By</td>
                                    <th colspan="3" scope="colgroup">Customer</th>
                                    <th colspan="3" scope="colgroup">Consultant</th>
                                    <th colspan="2" scope="colgroup">Consultant</th>
                                </tr>
                                <tr>
                                    <th scope="col">PN</th>
                                    <th scope="col">Mail</th>
                                    <th scope="col">SMS</th>
                                    <th scope="col">PN</th>
                                    <th scope="col">Mail</th>
                                    <th scope="col">SMS</th>
                                    <th scope="col">In App</th>
                                    <th scope="col">Mail</th>
                                </tr>
                                <tr>
                                    <th scope="row">Customer Signed Up Successfully</th>
                                    <td>Customer / Admin</td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4" name="type[]" value="1" <?php  if(in_array(1,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(1)"></i></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="2" <?php  if(in_array(2,$datas)){echo "checked";} ?>></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Customer Added amount to Wallet</th>
                                    <td>Customer</td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="3" <?php  if(in_array(3,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(3)"></i></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Board Games</th>
                                    <td>Customer</td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="4" <?php  if(in_array(4,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(4)"></i></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="5" <?php  if(in_array(5,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="6" <?php  if(in_array(6,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(6)"></i></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Booking Reminder (Before 12 Hours)</th>
                                    <td>Automatically</td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="7" <?php  if(in_array(7,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="8" <?php  if(in_array(8,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(8)"></i></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="9" <?php  if(in_array(9,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="10" <?php  if(in_array(10,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(10)"></i></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Booking Reminder (Before 1 Hours)</th>
                                    <td>Automatically</td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="11" <?php  if(in_array(11,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="12" <?php  if(in_array(12,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(12)"></i></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="13" <?php  if(in_array(13,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="14" <?php  if(in_array(14,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(14)"></i></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Consultant Started Appointment</th>
                                    <td>Consultant</td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="15" <?php  if(in_array(15,$datas)){echo "checked";} ?>></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Customer Joined Appointment</th>
                                    <td>Customer</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="16" <?php  if(in_array(16,$datas)){echo "checked";} ?>></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Slot Time Expiry Reminder (Before 5 Min)</th>
                                    <td>Automatically</td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="17" <?php  if(in_array(17,$datas)){echo "checked";} ?>></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="18" <?php  if(in_array(18,$datas)){echo "checked";} ?>></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Consultant Completed Appoinment</th>
                                    <td>Consultant</td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="19" <?php  if(in_array(19,$datas)){echo "checked";} ?>></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="20" <?php  if(in_array(20,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(20)"></i></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Customer Submitted Review & Rating</th>
                                    <td>Customer</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="21" <?php  if(in_array(21,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="22" <?php  if(in_array(22,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(22)"></i></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Consultant Reported review & Rating</th>
                                    <td>Consultant</td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="23" <?php  if(in_array(23,$datas)){echo "checked";} ?>></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="24" <?php  if(in_array(24,$datas)){echo "checked";} ?>></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Payin Reminder (Every Day) for completed appoinments</th>
                                    <td>Automatically</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="25" <?php  if(in_array(25,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="26" <?php  if(in_array(26,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(26)"></i></td>
                                </tr>
                                <tr>
                                    <th scope="row">Admin approves pay in (For Completed Appoinments)</th>
                                    <td>Admin</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="27" <?php  if(in_array(27,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="28" <?php  if(in_array(28,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(28)"></i></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Admin denies pay in (For Completed Appoinments)</th>
                                    <td>Admin</td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="29" <?php  if(in_array(29,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="30" <?php  if(in_array(30,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(30)"></i></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="31" <?php  if(in_array(31,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="32" <?php  if(in_array(32,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(32)"></i></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Customer Cancel Appoinment (Before Grace Period)</th>
                                    <td>Customer / Admin</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="33" <?php  if(in_array(33,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="34" <?php  if(in_array(34,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(34)"></i></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Customer Cancel Appoinment (After Grace Period)</th>
                                    <td>Customer / Admin</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="35" <?php  if(in_array(35,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="36" <?php  if(in_array(36,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(36)"></i></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Consultant Cancel Appoinment (Before Grace Period)</th>
                                    <td>Consultant</td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="37" <?php  if(in_array(37,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="38" <?php  if(in_array(38,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(38)"></i></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="39" <?php  if(in_array(39,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(39)"></i></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="40" <?php  if(in_array(40,$datas)){echo "checked";} ?>></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Customer Reschedule Appoinment (Before Grace Period)</th>
                                    <td>Customer / Admin /Consultant</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="41" <?php  if(in_array(41,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="42" <?php  if(in_array(42,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(42)"></i></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Customer Reschedule Appoinment (After Grace Period)</th>
                                    <td> Admin /Consultant</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="43" <?php  if(in_array(43,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="44" <?php  if(in_array(44,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(44)"></i></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">No Show Appointments</th>
                                    <td>Consultant / Admin</td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="45" <?php  if(in_array(45,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="46" <?php  if(in_array(46,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(46)"></i></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="47" <?php  if(in_array(47,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="48" <?php  if(in_array(48,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(48)"></i></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Consultant Signed Up Successfully</th>
                                    <td>Consultant</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="49" <?php  if(in_array(49,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(49)"></i></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="50" <?php  if(in_array(50,$datas)){echo "checked";} ?>></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Consultant Approves Appointment (Paid by Insurance)</th>
                                    <td>Consultant / Admin</td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="51" <?php  if(in_array(51,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="52" <?php  if(in_array(52,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(52)"></i></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Consultant Denies Appointment (Paid by Insurance)</th>
                                    <td>Consultant / Admin</td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="53" <?php  if(in_array(53,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="54" <?php  if(in_array(54,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(54)"></i></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Consultant Request for Payout</th>
                                    <td>Consultant</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="55" <?php  if(in_array(55,$datas)){echo "checked";} ?>></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="56" <?php  if(in_array(56,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(56)"></i></td>
                                </tr>
                                <tr>
                                    <th scope="row">Admin approves pay out</th>
                                    <td>Admin</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="57" <?php  if(in_array(57,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(57)"></i></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="58" <?php  if(in_array(58,$datas)){echo "checked";} ?>></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="59" <?php  if(in_array(59,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(59)"></i></td>
                                </tr>
                                <tr>
                                    <th scope="row">Admin denies pay out</th>
                                    <td>Admin</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="60" <?php  if(in_array(60,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(60)"></i></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="61" <?php  if(in_array(61,$datas)){echo "checked";} ?>></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="62" <?php  if(in_array(62,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(62)"></i></td>
                                </tr>
                                <tr>
                                    <th scope="row">Schedule not entered (prior to 7 days, 3 days, 1 day)</th>
                                    <td>Automatically</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="63" <?php  if(in_array(63,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(63)"></i></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="64" <?php  if(in_array(64,$datas)){echo "checked";} ?>></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Admin approves profile</th>
                                    <td>Admin</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="65" <?php  if(in_array(65,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(65)"></i></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="66" <?php  if(in_array(66,$datas)){echo "checked";} ?>></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Admin denies profile</th>
                                    <td>Admin</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="67" <?php  if(in_array(67,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(67)"></i></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="68" <?php  if(in_array(68,$datas)){echo "checked";} ?>></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Customer Purchased offer</th>
                                    <td>Customer</td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="69" <?php  if(in_array(69,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(69)"></i></td>
                                    <td></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="70" <?php  if(in_array(70,$datas)){echo "checked";} ?>><br>
                                    <i class='fas fa-exclamation-circle' onclick="Myfunction(70)"></i></td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="71" <?php  if(in_array(71,$datas)){echo "checked";} ?>></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Offer Posted</th>
                                    <td>Consultant / Admin</td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="72" <?php  if(in_array(72,$datas)){echo "checked";} ?>></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tr>
                                    <th scope="row">Discount Posted</th>
                                    <td>Consultant / Admin</td>
                                    <td><input type="checkbox" class="form-check-input mb-4 " name="type[]" value="73"></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                                <tbody>
                                </table>
                                <button type="submit" class="btn btn-info" style="margin-left: 629px;">Save</button>
                            </form>
                            </div>
                        </div>
                    </div>
                    <!--end::Card body-->
                </div>
            </div>
            <!--end::Content container-->
        </div>
        <!--end::Content-->
    </div>
    <!-- Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered mw-650px">
        <div class="modal-content rounded">
            <div class="modal-header pb-0 border-0 justify-content-end">
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <span class="svg-icon svg-icon-1">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                </div>
            </div>
            <div class="modal-body scroll-y px-10 px-lg-15 pt-0 pb-15">
                <form id="exampleModal77" class="form" action="#" method="post">
                    @csrf
                    <div class="d-flex flex-column mb-8 fv-row">
                        <label class="d-flex align-items-center fs-6 fw-bold mb-2">
                            <span class="required">Title or Subject</span>
                        </label>
                        <textarea class="form-control" required placeholder="" required name="title" ></textarea>
                        <input type="hidden" name="type" value="" class="set_type">
                    </div>

                    <div class="d-flex flex-column mb-8">
                        <label class="required fs-6 fw-bold mb-2">Variables</label>
                        <textarea class="form-control" required placeholder="" disabled required name="" >
                            {subject}
                            {message}
                        </textarea>
                    </div>
                    <div class="d-flex flex-column mb-8">
                        <label class="required fs-6 fw-bold mb-2">Description of Body</label>                        
                        <textarea id="register_address" name="description" required class="tox-target"></textarea>
                    </div>            
                    <div class="text-center">
                        <button type="reset" class="btn btn-light me-3 kt_modal_new_target_cancel">Cancel</button>
                        <button type="submit" class="btn btn-primary kt_modal_new_target_submit">
                            <span class="indicator-label">Submit</span>
                            <span class="indicator-progress">Please wait...
                            <span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@section('scripts')
<script src='{{ URL::asset(theme()->getDemo().'/plugins/custom/flatpickr/flatpickr.bundle.js')}}'></script>
<script src='{{ URL::asset(theme()->getDemo().'/plugins/custom/tinymce/tinymce.bundle.js')}}'></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jstree/3.2.1/jstree.min.js"></script>
<script src='{{ URL::asset(theme()->getDemo().'/plugins/custom/fslightbox/fslightbox.bundle.js') }}'></script>
<script src="{{ URL::asset(theme()->getDemo().'/js/template.js') }}"></script>
<script>
    const updateURL = `{{ route('notification.notification.template-store') }}`    
    </script>
<script>

var options2 = {selector: "#register_address"};

if (KTApp.isDarkMode()) {
            options2["skin"] = "oxide-dark";
            options2["content_css"] = "dark";
        }

        tinymce.init(options2);



function Myfunction(val)
{
    $('.set_type').val(val);
    $('#exampleModal').modal('show');
}
</script>
@endsection
</x-base-layout>
