<div class="" data-kt-stepper-element="content">
    <!--begin::Wrapper-->
    <div class="w-100" >
        <!--begin::Heading-->
        <div class="pb-10 pb-lg-15" >
            <!--begin::Title-->
            <h2 class="fw-bolder text-dark">Specialized </h2>
            <!--end::Title-->
            <!--begin::Notice-->
            <div class="text-muted fw-bold fs-6"></div>
            <!--end::Notice-->
        </div>
        <div class="fv-row mb-10" id="specialized" >
        </div>
    </div>
    <!--end::Wrapper-->
</div>
