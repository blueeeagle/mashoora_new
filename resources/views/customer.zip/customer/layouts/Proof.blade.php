<div class="" data-kt-stepper-element="content">
    <!--begin::Wrapper-->
    <div class="w-100" >
        <!--begin::Heading-->
        <div class="pb-8 pb-lg-10">
            <!--begin::Title-->
            <h2 class="fw-bolder text-dark">Proof</h2>
        </div>
        
        <div class="form-group row" id="proof_clone"></div>

    </div>
    <!--end::Wrapper-->
</div>
