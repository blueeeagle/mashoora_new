@include('customer.view_layouts.model.personal_details')
